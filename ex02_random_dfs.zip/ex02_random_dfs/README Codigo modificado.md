# DFS Explorer
Algoritmo modificado com Exploração DFS, retorno para a base com A* e clusterização por K-means

Como rodar:
- Apenas digite no terminal 'python main.py'
- Caso queira modificar o tamanho do mapa, passe como argumento o arquivo correspondente. 
- Por exemplo: 'python main.py datasets/data_42v_20x20'
         
